package modelos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author samuel hernandez
 */
public class Sinapsis {
    private Neurona origen;
    private Neurona destino;
    private double distancia;
    private String idNeurotransmisor;
    
    private double coeficienteEficiencia; //
    
    public void setCoeficienteEficiencia(double k) { 
        this.coeficienteEficiencia = k; 
    }
    public Sinapsis(Neurona origen, Neurona destino, double distancia, String idNeurotransmisor, double coeficienteEficiencia) {
        this.origen = origen;
        this.destino = destino;
        this.distancia = distancia;
        this.idNeurotransmisor = idNeurotransmisor;
        this.coeficienteEficiencia = coeficienteEficiencia;
    }
    
    // Getters
    public double getDistancia() { return distancia; }
    public String getIdNeurotransmisor() { return idNeurotransmisor; }
    public double getCoeficienteEficiencia() { return coeficienteEficiencia; }
    public Neurona getDestino() { return destino; }
}
