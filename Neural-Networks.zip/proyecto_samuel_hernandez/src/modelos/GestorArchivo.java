package modelos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author samuel hernandez
 */
public class GestorArchivo {
    // Método para cargar el CSV de las sinapsis 
    public void cargarRedSinaptica() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Seleccionar Archivo de Red Sináptica (CSV)");
        
        // Filtro para que solo busque archivos de texto plano 
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos CSV & TXT", "csv", "txt");
        fileChooser.setFileFilter(filter);

        int seleccion = fileChooser.showOpenDialog(null);

        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            leerArchivoCSV(archivo);
        }
    }

    private void leerArchivoCSV(File archivo) {
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            boolean primeraLinea = true;

            while ((linea = br.readLine()) != null) {
                // Saltar el encabezado o líneas vacías
                if (primeraLinea || linea.trim().isEmpty()) {
                    primeraLinea = false;
                    continue;
                }

                // Separar por comas
                String[] datos = linea.split(",");
                
                if (datos.length == 5) {
                    String idOrigen = datos[0].trim();
                    String idDestino = datos[1].trim();
                    double distancia = Double.parseDouble(datos[2].trim());
                    String idNeuro = datos[3].trim();
                    double coeficiente = Double.parseDouble(datos[4].trim());

                    // TODO: Aquí instanciaremos las Neuronas y Sinapsis 
                    // para agregarlas a nuestro GrafoNeuronal personalizado.
                    System.out.println("Leído: " + idOrigen + " -> " + idDestino + " | Neuro: " + idNeuro);
                }
            }
            System.out.println("Archivo cargado exitosamente.");
            
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error en el formato de los números del archivo CSV.");
        }
    }
}
