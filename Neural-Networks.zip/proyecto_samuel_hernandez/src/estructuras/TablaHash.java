/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructuras;
import modelos.Neurotransmisor;

/**
 *
 * @author samuel hernandez
 */
public class TablaHash {
    
    private static final int CAPACIDAD_INICIAL = 31; // Número primo para reducir colisiones
    private ListaEnlazada<EntradaHash>[] tabla;

    // Clase interna para representar los pares clave-valor
    private static class EntradaHash {
        String clave;
        Neurotransmisor valor;

        EntradaHash(String clave, Neurotransmisor valor) {
            this.clave = clave;
            this.valor = valor;
        }
    }

    @SuppressWarnings("unchecked")
    public TablaHash() {
        tabla = new ListaEnlazada[CAPACIDAD_INICIAL];
        for (int i = 0; i < CAPACIDAD_INICIAL; i++) {
            tabla[i] = new ListaEnlazada<>();
        }
    }

    // Función de dispersión (Hash Function)
    private int calcularIndice(String clave) {
        int hash = 0;
        for (int i = 0; i < clave.length(); i++) {
            hash = (31 * hash + clave.charAt(i)) % CAPACIDAD_INICIAL;
        }
        return Math.abs(hash);
    }

    // Insertar en la tabla con complejidad O(1)
    public void put(String clave, Neurotransmisor valor) {
        int indice = calcularIndice(clave);
        ListaEnlazada<EntradaHash> lista = tabla[indice];

        // Verificar si la clave ya existe para actualizarla
        for (int i = 0; i < lista.getTamano(); i++) {
            EntradaHash entrada = lista.obtener(i);
            if (entrada.clave.equals(clave)) {
                entrada.valor = valor;
                return;
            }
        }

        // Si no existe, se agrega una nueva entrada
        lista.agregar(new EntradaHash(clave, valor));
    }

    // Buscar en la tabla con complejidad O(1)
    public Neurotransmisor get(String clave) {
        int indice = calcularIndice(clave);
        ListaEnlazada<EntradaHash> lista = tabla[indice];

        for (int i = 0; i < lista.getTamano(); i++) {
            EntradaHash entrada = lista.obtener(i);
            if (entrada.clave.equals(clave)) {
                return entrada.valor;
            }
        }
        return null; // No encontrado
    }
}
