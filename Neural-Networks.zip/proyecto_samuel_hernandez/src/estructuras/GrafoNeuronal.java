/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructuras;

import modelos.Neurona;
import modelos.Sinapsis;
/**
 *
 * @author samuel hernandez
 */
public class GrafoNeuronal {
    private ListaEnlazada<Neurona> neuronas;

    public GrafoNeuronal() {
        this.neuronas = new ListaEnlazada<>();
    }

    // Busca una neurona por ID; si no existe, la crea (Evita duplicados)
    public Neurona obtenerOCrearNeurona(String id) {
        Neurona encontrada = buscarNeurona(id);
        if (encontrada == null) {
            encontrada = new Neurona(id);
            neuronas.agregar(encontrada);
        }
        return encontrada;
    }

    public Neurona buscarNeurona(String id) {
        for (int i = 0; i < neuronas.getTamano(); i++) {
            if (neuronas.obtener(i).getId().equals(id)) {
                return neuronas.obtener(i);
            }
        }
        return null;
    }

    // Conecta dos neuronas de forma unidireccional (Axón a Dendrita)
    public void conectarNeuronas(String idOrigen, String idDestino, double distancia, String idNeuro, double k) {
        Neurona origen = obtenerOCrearNeurona(idOrigen);
        Neurona destino = obtenerOCrearNeurona(idDestino);

        Sinapsis nuevaSinapsis = new Sinapsis(origen, destino, distancia, idNeuro, k);
        origen.agregarSinapsis(nuevaSinapsis);
    }

    public ListaEnlazada<Neurona> getNeuronas() {
        return neuronas;
    }
    /**
     * Requerimiento G: Eliminar una neurona y todas sus conexiones entrantes/salientes.
     */
    public boolean eliminarNeurona(String id) {
        Neurona objetivo = buscarNeurona(id);
        if (objetivo == null) {
            return false; // La neurona no existe
        }

        // 1. Eliminar la neurona de la lista principal de vértices
        for (int i = 0; i < neuronas.getTamano(); i++) {
            if (neuronas.obtener(i).getId().equals(id)) {
                neuronas.eliminar(i);
                break;
            }
        }

        // 2. Limpiar las sinapsis entrantes (recorrer las demás neuronas)
        for (int i = 0; i < neuronas.getTamano(); i++) {
            Neurona actual = neuronas.obtener(i);
            estructuras.ListaEnlazada<modelos.Sinapsis> sinapsis = actual.getSinapsisSalientes();
            
            for (int j = 0; j < sinapsis.getTamano(); j++) {
                if (sinapsis.obtener(j).getDestino().getId().equals(id)) {
                    sinapsis.eliminar(j);
                    j--; // Ajustar el índice porque la lista se redujo
                }
            }
        }
        System.out.println("Neurona " + id + " y sus conexiones han sido eliminadas.");
        return true;
}
}