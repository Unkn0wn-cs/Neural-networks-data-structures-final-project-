/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package control;

import estructuras.TablaHash;
import estructuras.GrafoNeuronal;
import modelos.Neurotransmisor;
import javax.swing.JFileChooser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author samuel hernandez
 */
public class GestorArchivo {
    // Carga el archivo de neurotransmisores y los guarda en la Tabla Hash
    public void cargarDiccionario(TablaHash tablaHash) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Cargar Diccionario de Neurotransmisores");
        
        if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                boolean primeraLinea = true;

                while ((linea = br.readLine()) != null) {
                    if (primeraLinea || linea.trim().isEmpty()) {
                        primeraLinea = false;
                        continue;
                    }
                    String[] datos = linea.split(",");
                    if (datos.length >= 5) {
                        String id = datos[0].trim();
                        String nombre = datos[1].trim();
                        String efecto = datos[2].trim();
                        double velocidad = Double.parseDouble(datos[3].trim());
                        
                        // Reconstruir la descripción en caso de que tuviera comas internas
                        String descripcion = datos[4].trim();

                        Neurotransmisor nt = new Neurotransmisor(id, nombre, efecto, velocidad, descripcion);
                        tablaHash.put(id, nt); // Inserción O(1)[cite: 1, 2]
                    }
                }
                System.out.println("Diccionario químico cargado con éxito.");
            } catch (Exception e) {
                System.out.println("Error al cargar el diccionario: " + e.getMessage());
            }
        }
    }

    // Carga la red sináptica mapeando con el Grafo y calculando los pesos dinámicos[cite: 1, 2]
    public void cargarRedSinaptica(GrafoNeuronal grafo, TablaHash tablaHash) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Cargar Red Sináptica");

        if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                boolean primeraLinea = true;

                while ((linea = br.readLine()) != null) {
                    if (primeraLinea || linea.trim().isEmpty()) {
                        primeraLinea = false;
                        continue;
                    }
                    String[] datos = linea.split(",");
                    if (datos.length == 5) {
                        String origen = datos[0].trim();
                        String destino = datos[1].trim();
                        double distancia = Double.parseDouble(datos[2].trim());
                        String idNeuro = datos[3].trim();
                        double k = Double.parseDouble(datos[4].trim());

                        // Registrar la conexión en el grafo dirigido[cite: 1]
                        grafo.conectarNeuronas(origen, destino, distancia, idNeuro, k);
                        
                        // Demostración de cálculo de peso W dinámico usando la fórmula[cite: 1]
                        Neurotransmisor nt = tablaHash.get(idNeuro);
                        if (nt != null) {
                            double pesoW = distancia / (nt.getVelocidad() * k);
                            System.out.println("Conexión " + origen + "->" + destino + " con Peso W = " + pesoW);
                        }
                    }
                }
                System.out.println("Grafo Neuronal generado completamente en memoria.");
            } catch (Exception e) {
                System.out.println("Error al cargar la red sináptica: " + e.getMessage());
            }
        }
    }
}
