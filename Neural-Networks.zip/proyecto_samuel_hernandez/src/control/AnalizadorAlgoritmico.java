/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import estructuras.GrafoNeuronal;
import estructuras.ListaEnlazada;
import estructuras.TablaHash;
import modelos.Neurona;
import modelos.Sinapsis;
import modelos.Neurotransmisor;
/**
 *
 * @author samuel hernandez
 */
public class AnalizadorAlgoritmico {
   /**
     * Requerimiento B: Detección de zonas aisladas usando DFS.
     * Retorna una lista con las neuronas que son inalcanzables desde el origen.
     */
    public ListaEnlazada<Neurona> detectarZonasAisladas(GrafoNeuronal grafo, String idOrigen) {
        ListaEnlazada<Neurona> todas = grafo.getNeuronas();
        
        // 1. Reiniciar el estado de todas las neuronas a "no visitadas"
        for (int i = 0; i < todas.getTamano(); i++) {
            todas.obtener(i).setVisitada(false);
        }

        // 2. Iniciar el recorrido DFS desde la neurona fuente
        Neurona origen = grafo.buscarNeurona(idOrigen);
        if (origen != null) {
            dfs(origen);
        }

        // 3. Recopilar las zonas que quedaron aisladas (inalcanzables)
        ListaEnlazada<Neurona> zonasAisladas = new ListaEnlazada<>();
        for (int i = 0; i < todas.getTamano(); i++) {
            Neurona n = todas.obtener(i);
            if (!n.isVisitada()) {
                zonasAisladas.agregar(n);
            }
        }

        return zonasAisladas;
    }

    // Método recursivo para Búsqueda en Profundidad (DFS)
    private void dfs(Neurona actual) {
        // Marcar como visitada
        actual.setVisitada(true);

        // Recorrer todas sus conexiones salientes
        ListaEnlazada<Sinapsis> adyacentes = actual.getSinapsisSalientes();
        for (int i = 0; i < adyacentes.getTamano(); i++) {
            Sinapsis enlace = adyacentes.obtener(i);
            Neurona destino = enlace.getDestino();
            
            // Si el destino no ha sido visitado, profundizar por ahí
            if (!destino.isVisitada()) {
                dfs(destino);
            }
        }
    }

    /**
     * Requerimiento F: Simular deterioro cognitivo por fatiga.
     * Recorre todo el grafo y multiplica el factor k por 1.2.
     */
    public void simularFatigaGlobal(GrafoNeuronal grafo) {
        ListaEnlazada<Neurona> neuronas = grafo.getNeuronas();
        
        for (int i = 0; i < neuronas.getTamano(); i++) {
            Neurona n = neuronas.obtener(i);
            ListaEnlazada<Sinapsis> sinapsis = n.getSinapsisSalientes();
            
            for (int j = 0; j < sinapsis.getTamano(); j++) {
                Sinapsis s = sinapsis.obtener(j);
                double nuevoK = s.getCoeficienteEficiencia() * 1.2;
                s.setCoeficienteEficiencia(nuevoK);
            }
        }
        System.out.println("Se ha aplicado la fatiga. Coeficientes 'k' multiplicados por 1.2.");
    }

    /**
     * =========================================================================
     * AVANCE 5 - REQUERIMIENTO E: Ruta de Mayor Activación (Algoritmo de Dijkstra)
     * =========================================================================
     * Calcula el camino más rápido entre dos neuronas basándose en el peso dinámico W.
     */
    public ListaEnlazada<Neurona> calcularRutaMasRapida(GrafoNeuronal grafo, String idOrigen, String idDestino, TablaHash diccionario) {
        ListaEnlazada<Neurona> neuronas = grafo.getNeuronas();
        int n = neuronas.getTamano();

        // Arreglos de control que mapean 1:1 con las posiciones de la ListaEnlazada
        double[] distancias = new double[n];
        int[] previos = new int[n];
        boolean[] procesados = new boolean[n];

        // 1. Inicialización de estructuras de control
        for (int i = 0; i < n; i++) {
            distancias[i] = Double.MAX_VALUE; // Equivalente a infinito
            previos[i] = -1;                 // No hay nodo previo conocido
            procesados[i] = false;           // Ninguno ha sido evaluado aún
        }

        // Obtener los índices internos de los IDs solicitados
        int indiceOrigen = obtenerIndicePorId(neuronas, idOrigen);
        int indiceDestino = obtenerIndicePorId(neuronas, idDestino);

        // Validación de existencia
        if (indiceOrigen == -1 || indiceDestino == -1) {
            System.out.println("Error: Origen o destino no se encuentran en la red.");
            return new ListaEnlazada<>(); // Retorna lista vacía
        }

        // La distancia a sí mismo siempre es 0
        distancias[indiceOrigen] = 0.0;

        // 2. Ciclo principal del algoritmo de Dijkstra
        for (int i = 0; i < n - 1; i++) {
            // Buscamos manualmente el nodo con la menor distancia acumulada que no esté procesado
            int u = obtenerIndiceMinimaDistancia(distancias, procesados, n);
            
            // Si ya no hay nodos alcanzables, rompemos el ciclo
            if (u == -1 || distancias[u] == Double.MAX_VALUE) {
                break;
            }

            procesados[u] = true;
            Neurona neuronaActual = neuronas.obtener(u);
            ListaEnlazada<Sinapsis> adyacentes = neuronaActual.getSinapsisSalientes();

            // 3. Relajación de aristas adyacentes
            for (int j = 0; j < adyacentes.getTamano(); j++) {
                Sinapsis enlace = adyacentes.obtener(j);
                int v = obtenerIndicePorId(neuronas, enlace.getDestino().getId());

                if (v != -1 && !procesados[v]) {
                    // O(1): Consultamos el neurotransmisor en nuestra Tabla Hash propia
                    Neurotransmisor nt = diccionario.get(enlace.getIdNeurotransmisor());
                    double velocidad = (nt != null) ? nt.getVelocidad() : 1.0; // Resguardo por si acaso

                    // FÓRMULA DEL ENUNCIADO: W = d / (v * k)
                    double pesoW = enlace.getDistancia() / (velocidad * enlace.getCoeficienteEficiencia());

                    // Si encontramos un camino más corto hacia 'v' pasando por 'u'
                    if (distancias[u] + pesoW < distancias[v]) {
                        distancias[v] = distancias[u] + pesoW;
                        previos[v] = u; // Guardamos el rastro para reconstruir la ruta
                    }
                }
            }
        }

        // 4. Reconstrucción del camino de regreso
        return reconstruirCaminoFrontera(neuronas, previos, indiceDestino, indiceOrigen);
    }

    // --- MÉTODOS AUXILIARES PROPIOS PARA DIJKSTRA ---

    // Busca cuál es el nodo con menor distancia que aún falta por procesar
    private int obtenerIndiceMinimaDistancia(double[] distancias, boolean[] procesados, int n) {
        double min = Double.MAX_VALUE;
        int indiceMin = -1;

        for (int i = 0; i < n; i++) {
            if (!procesados[i] && distancias[i] <= min) {
                min = distancias[i];
                indiceMin = i;
            }
        }
        return indiceMin;
    }

    // Mapea el ID de la neurona con su posición en la ListaEnlazada
    private int obtenerIndicePorId(ListaEnlazada<Neurona> neuronas, String id) {
        for (int i = 0; i < neuronas.getTamano(); i++) {
            if (neuronas.obtener(i).getId().equals(id)) {
                return i;
            }
        }
        return -1;
    }

    // Rastrea los índices guardados en 'previos' desde el destino hacia atrás y los invierte para dar la ruta correcta
    private ListaEnlazada<Neurona> reconstruirCaminoFrontera(ListaEnlazada<Neurona> neuronas, int[] previos, int destino, int origen) {
        ListaEnlazada<Neurona> rutaInversa = new ListaEnlazada<>();
        int actual = destino;

        // Si el destino no tiene un nodo previo y no es el origen mismo, es inalcanzable
        if (previos[actual] == -1 && actual != origen) {
            return new ListaEnlazada<>(); // Destino inalcanzable
        }

        while (actual != -1) {
            rutaInversa.agregar(neuronas.obtener(actual));
            actual = previos[actual];
        }

        // Como se construyó de atrás hacia adelante, la invertimos para el usuario
        ListaEnlazada<Neurona> rutaCorrecta = new ListaEnlazada<>();
        for (int i = rutaInversa.getTamano() - 1; i >= 0; i--) {
            rutaCorrecta.agregar(rutaInversa.obtener(i));
        }

        return rutaCorrecta;
    }
}
