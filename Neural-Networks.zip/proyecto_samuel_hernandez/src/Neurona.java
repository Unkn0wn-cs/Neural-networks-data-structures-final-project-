/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author samuel hernandez
 */
public class Neurona {
    private String id;
    
    public Neurona(String id) {
        this.id = id;
    }

    public String getId() { return id; }
}
