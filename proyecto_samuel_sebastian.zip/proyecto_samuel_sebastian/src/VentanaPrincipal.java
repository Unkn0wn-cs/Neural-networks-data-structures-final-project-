/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import estructuras.GrafoNeuronal;
import estructuras.TablaHash;
import estructuras.ListaEnlazada;
import modelos.Neurona;
import control.GestorArchivo;
import control.AnalizadorAlgoritmico;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.view.Viewer;
import org.graphstream.ui.swing_viewer.ViewPanel;
/**
 *
 * @author samuel hernandez
 */
/**
 * VentanaPrincipal
 * Interfaz gráfica principal. Contiene controles para cargar datos, ejecutar
 * algoritmos (BFS/DFS/Dijkstra), modificar la red y visualizarla con GraphStream.
 */
public class VentanaPrincipal extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName());
        // Instancias lógicas del sistema (El cerebro de la ventana)
        private GrafoNeuronal miGrafo;
        private TablaHash miDiccionario;
        private GestorArchivo gestor;
        private AnalizadorAlgoritmico analizador;

        // GraphStream UI
        private org.graphstream.graph.Graph gsGraph;
        private org.graphstream.ui.view.Viewer gsViewer;
        private org.graphstream.ui.swing_viewer.ViewPanel gsViewPanel;
        private javax.swing.JPanel panelGraph;
        private javax.swing.JTextField txtSearchField;
        private javax.swing.JTextField txtAddNodeField;
        private javax.swing.JTextField txtRemoveNodeField;
        private javax.swing.JLabel statusLabel;
    /**
     * Creates new form VentanaPrincipal
     */
    public VentanaPrincipal() {
        initComponents();
        this.setLocationRelativeTo(null); // Centra la ventana en la pantalla
        
        // Inicializar las estructuras de datos
        this.miGrafo = new GrafoNeuronal();
        this.miDiccionario = new TablaHash(); 
        this.gestor = new GestorArchivo();
        this.analizador = new AnalizadorAlgoritmico();

        // Inicializar panel del grafo y controles
        initGraphPanel();
    }
// ====================================================================
    // MÉTODOS PARA CONECTAR CON LOS BOTONES (Lógica del Avance 8)
    // ====================================================================

    public void accionCargarDiccionario() {
        gestor.cargarDiccionario(miDiccionario);
    }

    public void accionCargarRed() {
        gestor.cargarRedSinaptica(miGrafo, miDiccionario);
    }

    public void accionSimularFatiga() {
        if (miGrafo == null || miGrafo.getNeuronas().getTamano() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Debe cargar la red primero.");
            return;
        }
        miGrafo.simularDeterioroPorFatiga();
        javax.swing.JOptionPane.showMessageDialog(this, "Fatiga inducida: Coeficientes 'k' incrementados en 20%.");
    }

    public void accionGuardarCSV() {
        if (miGrafo == null || miGrafo.getNeuronas().getTamano() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "No hay red para guardar.");
            return;
        }

        javax.swing.JFileChooser fileChooser = new javax.swing.JFileChooser();
        if (fileChooser.showSaveDialog(this) == javax.swing.JFileChooser.APPROVE_OPTION) {
            String ruta = fileChooser.getSelectedFile().getAbsolutePath();
            if (!ruta.toLowerCase().endsWith(".csv")) ruta += ".csv";
            
            if (miGrafo.guardarGrafoEnCSV(ruta)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Archivo guardado exitosamente.");
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar el archivo.");
            }
        }
    }

    public void accionCalcularRuta(String idOrigen, String idDestino) {
        if (idOrigen.isEmpty() || idDestino.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese ambos IDs.");
            return;
        }

        ListaEnlazada<Neurona> ruta = miGrafo.calcularRutaMasRapida(idOrigen, idDestino, miDiccionario);

        if (ruta.getTamano() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "No hay ruta activa.");
        } else {
            StringBuilder sb = new StringBuilder("Ruta encontrada:\n");
            for (int i = 0; i < ruta.getTamano(); i++) {
                sb.append(ruta.obtener(i).getId());
                if (i < ruta.getTamano() - 1) sb.append(" -> ");
            }
            javax.swing.JOptionPane.showMessageDialog(this, sb.toString());
        }
    }
    private void initGraphPanel() {
        // GraphStream bridge to Swing
        System.setProperty("org.graphstream.ui", "swing");

        // Top toolbar
        javax.swing.JToolBar toolbar = new javax.swing.JToolBar();
        toolbar.setFloatable(false);
        javax.swing.JButton btnCargarDic = new javax.swing.JButton("Cargar Diccionario");
        javax.swing.JButton btnVerDic = new javax.swing.JButton("Ver Diccionario");
        javax.swing.JButton btnAgregarNT = new javax.swing.JButton("Agregar NT");
        javax.swing.JButton btnEliminarNT = new javax.swing.JButton("Eliminar NT");
        javax.swing.JButton btnCargarRed = new javax.swing.JButton("Cargar Red");
        javax.swing.JButton btnFatiga = new javax.swing.JButton("Simular Fatiga");
        javax.swing.JButton btnGuardar = new javax.swing.JButton("Guardar CSV");
        javax.swing.JButton btnAgregarConexion = new javax.swing.JButton("Agregar Conexión");
        javax.swing.JButton btnEliminarConexion = new javax.swing.JButton("Eliminar Conexión");
        toolbar.add(btnCargarDic);
        toolbar.add(btnVerDic);
        toolbar.add(btnAgregarNT);
        toolbar.add(btnEliminarNT);
        toolbar.add(btnCargarRed);
        toolbar.add(btnFatiga);
        toolbar.add(btnAgregarConexion);
        toolbar.add(btnEliminarConexion);
        toolbar.add(btnGuardar);

        // Controls panel (search, origin/destination, add/remove)
        javax.swing.JPanel controls = new javax.swing.JPanel(new FlowLayout(FlowLayout.LEFT));
        controls.add(new javax.swing.JLabel("Buscar nodo:"));
        txtSearchField = new javax.swing.JTextField(10);
        controls.add(txtSearchField);
        javax.swing.JButton btnBuscar = new javax.swing.JButton("Buscar");
        controls.add(btnBuscar);

        controls.add(new javax.swing.JLabel("Origen:"));
        final javax.swing.JTextField txtOrigenUI = new javax.swing.JTextField(6);
        controls.add(txtOrigenUI);
        controls.add(new javax.swing.JLabel("Destino:"));
        final javax.swing.JTextField txtDestinoUI = new javax.swing.JTextField(6);
        controls.add(txtDestinoUI);
        javax.swing.JButton btnCalcularRutaUI = new javax.swing.JButton("Calcular Ruta");
        controls.add(btnCalcularRutaUI);

        // Detectar zonas aisladas
        javax.swing.JButton btnDetectarDFS = new javax.swing.JButton("Detectar Aislados (DFS)");
        javax.swing.JButton btnDetectarBFS = new javax.swing.JButton("Detectar Aislados (BFS)");
        controls.add(btnDetectarDFS);
        controls.add(btnDetectarBFS);

        // Add / Remove nodes
        controls.add(new javax.swing.JLabel("Agregar nodo:"));
        txtAddNodeField = new javax.swing.JTextField(6);
        controls.add(txtAddNodeField);
        javax.swing.JButton btnAgregarNodo = new javax.swing.JButton("Agregar");
        controls.add(btnAgregarNodo);

        controls.add(new javax.swing.JLabel("Eliminar nodo:"));
        txtRemoveNodeField = new javax.swing.JTextField(6);
        controls.add(txtRemoveNodeField);
        javax.swing.JButton btnEliminarNodo = new javax.swing.JButton("Eliminar");
        controls.add(btnEliminarNodo);

        javax.swing.JPanel top = new javax.swing.JPanel(new BorderLayout());
        top.add(toolbar, BorderLayout.WEST);
        top.add(controls, BorderLayout.CENTER);

        // Replace content pane layout with BorderLayout and add top
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(top, BorderLayout.NORTH);

        // Panel para el grafo
        panelGraph = new javax.swing.JPanel(new BorderLayout());
        getContentPane().add(panelGraph, BorderLayout.CENTER);

        // Crear GraphStream graph
        gsGraph = new SingleGraph("RedNeuronal");
        String style = "node { fill-color: #6aa3ff; size: 56px; text-size: 16px; text-alignment: center; text-offset: 0px, -56px; text-background-mode: rounded-box; text-background-color: white; text-padding: 4px; text-color: black; } "
            + "edge { fill-color: #999; size: 2px; } "
            + "edge.strong { fill-color: #2E8B57; size: 4px; } "
            + "edge.medium { fill-color: #FFA500; size: 3px; } "
            + "edge.weak { fill-color: #FF6347; size: 1.5px; } "
            + "node.search { fill-color: #FFFF66; size: 66px; } "
            + "edge.search { fill-color: #FFD700; size: 5px; } "
            + "node.path { fill-color: #ff7f00; size: 66px; } "
            + "edge.path { fill-color: #ff7f00; size: 5px; } "
            + "node.bfs { fill-color: #2ecc71; size: 62px; } "
            + "edge.bfs { fill-color: #27ae60; size: 5px; } "
            + "node.dfs { fill-color: #9b59b6; size: 62px; } "
            + "edge.dfs { fill-color: #8e44ad; size: 5px; } "
            + "node.isolated { fill-color: #FF4444; }";
        gsGraph.setAttribute("ui.stylesheet", style);
        gsGraph.setAttribute("ui.quality", true);
        gsGraph.setAttribute("ui.antialias", true);

        gsViewer = new org.graphstream.ui.swing_viewer.SwingViewer(gsGraph, Viewer.ThreadingModel.GRAPH_IN_GUI_THREAD);
        gsViewer.enableAutoLayout();
        gsViewPanel = (ViewPanel) gsViewer.addDefaultView(false);
        panelGraph.add(gsViewPanel, BorderLayout.CENTER);

        statusLabel = new javax.swing.JLabel("Listo");
        statusLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(4,8,4,8));
        getContentPane().add(statusLabel, BorderLayout.SOUTH);

        // Button listeners
        btnCargarDic.addActionListener(e -> { accionCargarDiccionario(); actualizarGraphStreamDesdeGrafo(); });
        btnVerDic.addActionListener(e -> { mostrarDiccionario(); });
        btnAgregarNT.addActionListener(e -> { accionAgregarNeurotransmisorDialog(); });
        btnEliminarNT.addActionListener(e -> { String idnt = javax.swing.JOptionPane.showInputDialog(this, "ID del neurotransmisor a eliminar:"); if (idnt != null && !idnt.trim().isEmpty()) { boolean r = miDiccionario.remove(idnt.trim()); javax.swing.JOptionPane.showMessageDialog(this, r ? "Neurotransmisor eliminado." : "No encontrado."); } });
        btnCargarRed.addActionListener(e -> {
            if (miGrafo != null && miGrafo.getNeuronas().getTamano() > 0) {
                Object[] options = {"Guardar y continuar", "Descartar y continuar", "Cancelar"};
                int opt = javax.swing.JOptionPane.showOptionDialog(this, "Ya hay una red cargada en memoria. ¿Desea guardarla antes de cargar otra?", "Advertencia", javax.swing.JOptionPane.YES_NO_CANCEL_OPTION, javax.swing.JOptionPane.WARNING_MESSAGE, null, options, options[0]);
                if (opt == 0) { accionGuardarCSV(); accionCargarRed(); actualizarGraphStreamDesdeGrafo(); }
                else if (opt == 1) { miGrafo = new GrafoNeuronal(); accionCargarRed(); actualizarGraphStreamDesdeGrafo(); }
            } else {
                accionCargarRed(); actualizarGraphStreamDesdeGrafo();
            }
        });
        btnFatiga.addActionListener(e -> { accionSimularFatiga(); actualizarGraphStreamDesdeGrafo(); });
        btnAgregarConexion.addActionListener(e -> { accionAgregarConexionDialog(); });
        btnEliminarConexion.addActionListener(e -> { accionEliminarConexionDialog(); });
        btnGuardar.addActionListener(e -> { accionGuardarCSV(); });
        btnBuscar.addActionListener(e -> {
            String q = txtSearchField.getText().trim();
            if (q.isEmpty()) return;
            org.graphstream.graph.Node node = gsGraph.getNode(q);
            if (node != null) { highlightNode(q); return; }
            ListaEnlazada<String> matches = new ListaEnlazada<>();
            for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) {
                String nid = miGrafo.getNeuronas().obtener(i).getId();
                if (nid.toLowerCase().contains(q.toLowerCase())) matches.agregar(nid);
            }
            if (matches.getTamano() == 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Nodo no encontrado.");
            } else if (matches.getTamano() == 1) {
                highlightNode(matches.obtener(0));
            } else {
                String[] opts = new String[matches.getTamano()];
                for (int i = 0; i < matches.getTamano(); i++) opts[i] = matches.obtener(i);
                String sel = (String) javax.swing.JOptionPane.showInputDialog(this, "Seleccione un nodo:", "Resultados", javax.swing.JOptionPane.PLAIN_MESSAGE, null, opts, opts[0]);
                if (sel != null) highlightNode(sel);
            }
        });
        btnCalcularRutaUI.addActionListener(e -> {
            String o = txtOrigenUI.getText().trim();
            String d = txtDestinoUI.getText().trim();
            if (miGrafo == null || miGrafo.getNeuronas().getTamano() == 0) { statusLabel.setText("Cargue la red primero."); return; }
            if (o.isEmpty() || d.isEmpty()) { statusLabel.setText("Ingrese ambos IDs."); return; }
            ListaEnlazada<Neurona> ruta = miGrafo.calcularRutaMasRapida(o, d, miDiccionario);
            if (ruta.getTamano() > 0) {
                highlightPath(ruta);
                double pesoTotal = calcularPesoRuta(ruta);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < ruta.getTamano(); i++) {
                    sb.append(ruta.obtener(i).getId());
                    if (i < ruta.getTamano()-1) sb.append(" -> ");
                }
                statusLabel.setText("Ruta: " + sb.toString() + " | Peso total: " + String.format("%.2f", pesoTotal));
            } else {
                statusLabel.setText("No hay ruta activa entre " + o + " y " + d);
            }
        });
        btnDetectarDFS.addActionListener(e -> {
            String origin = txtOrigenUI.getText().trim();
            if (origin.isEmpty()) { statusLabel.setText("Ingrese ID de origen."); return; }
            highlightTraversalDFS(origin);
            ListaEnlazada<Neurona> aisl = analizador.detectarZonasAisladas(miGrafo, origin);
            highlightIsolatedNodes(aisl);
            int componentes = analizador.contarComponentesDebiles(miGrafo);
            boolean fuerte = analizador.esFuertementeConexo(miGrafo);
            StringBuilder msg = new StringBuilder();
            msg.append("Neurona fuente: ").append(origin);
            msg.append(" | Inalcanzables: ").append(aisl.getTamano());
            if (fuerte) msg.append(" | La red es fuertemente conexa.");
            else msg.append(" | Fragmentada en ").append(componentes).append(" componente(s).");
            statusLabel.setText(msg.toString());
        });
        btnDetectarBFS.addActionListener(e -> {
            String origin = txtOrigenUI.getText().trim();
            if (origin.isEmpty()) { statusLabel.setText("Ingrese ID de origen."); return; }
            highlightTraversalBFS(origin);
            ListaEnlazada<Neurona> aisl = analizador.detectarZonasAisladasBFS(miGrafo, origin);
            highlightIsolatedNodes(aisl);
            int componentes = analizador.contarComponentesDebiles(miGrafo);
            boolean fuerte = analizador.esFuertementeConexo(miGrafo);
            StringBuilder msg = new StringBuilder();
            msg.append("Neurona fuente: ").append(origin);
            msg.append(" | Inalcanzables: ").append(aisl.getTamano());
            if (fuerte) msg.append(" | La red es fuertemente conexa.");
            else msg.append(" | Fragmentada en ").append(componentes).append(" componente(s).");
            statusLabel.setText(msg.toString());
        });
        btnAgregarNodo.addActionListener(e -> { String nid = txtAddNodeField.getText().trim(); if (!nid.isEmpty()) { accionAgregarNodo(nid); actualizarGraphStreamDesdeGrafo(); } });
        btnEliminarNodo.addActionListener(e -> { String nid = txtRemoveNodeField.getText().trim(); if (!nid.isEmpty()) { accionEliminarNodo(nid); actualizarGraphStreamDesdeGrafo(); } });

        revalidate();
        repaint();
    }

    private void actualizarGraphStreamDesdeGrafo() {
        gsGraph.clear();
        // Añadir nodos
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) {
            Neurona n = miGrafo.getNeuronas().obtener(i);
            org.graphstream.graph.Node gn = gsGraph.addNode(n.getId());
            // Mostrar índice numérico encima del ID (línea superior) y nombre en la segunda línea
            gn.setAttribute("ui.label", String.format("%d\n\n%s", i + 1, n.getId()));
        }
        // Añadir aristas
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) {
            Neurona n = miGrafo.getNeuronas().obtener(i);
            ListaEnlazada lista = n.getSinapsisSalientes();
            for (int j = 0; j < lista.getTamano(); j++) {
                Object obj = lista.obtener(j);
                modelos.Sinapsis s = (modelos.Sinapsis) obj;
                String from = s.getOrigen().getId();
                String to = s.getDestino().getId();
                String eid = from + "_" + to + "_" + j;
                if (gsGraph.getEdge(eid) == null) {
                    org.graphstream.graph.Edge e = gsGraph.addEdge(eid, from, to, true);
                    double distancia = s.getDistancia();
                    modelos.Neurotransmisor nt = (modelos.Neurotransmisor) miDiccionario.get(s.getIdNeurotransmisor());
                    double velocidad = (nt != null) ? nt.getVelocidad() : 1.0;
                    double w = distancia / (velocidad * s.getCoeficienteEficiencia());
                    e.setAttribute("weight", w);
                    e.setAttribute("ui.label", String.format("%.2f", w));
                    if (w > 1.0) e.setAttribute("ui.class", "strong"); else if (w > 0.5) e.setAttribute("ui.class", "medium"); else e.setAttribute("ui.class", "weak");
                }
            }
        }
    }

    private void highlightNode(String id) {
        clearAllStyles();
        org.graphstream.graph.Node node = gsGraph.getNode(id);
        if (node != null) {
            node.setAttribute("ui.class", "search");

            // Resaltar aristas salientes del nodo buscado
            Neurona n = miGrafo.buscarNeurona(id);
            if (n != null) {
                ListaEnlazada sal = n.getSinapsisSalientes();
                for (int j = 0; j < sal.getTamano(); j++) {
                    modelos.Sinapsis s = (modelos.Sinapsis) sal.obtener(j);
                    String eid = id + "_" + s.getDestino().getId() + "_" + j;
                    org.graphstream.graph.Edge e = gsGraph.getEdge(eid);
                    if (e != null) e.setAttribute("ui.class", "search");
                }
            }
        } else {
            statusLabel.setText("Nodo no encontrado: " + id);
        }
    }

    private void highlightPath(ListaEnlazada<Neurona> ruta) {
        // Clear node and edge styles
        for (org.graphstream.graph.Node n : gsGraph) {
            n.removeAttribute("ui.class");
        }
        // Clear edge styles using model data
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) {
            Neurona nn = miGrafo.getNeuronas().obtener(i);
            ListaEnlazada lista = nn.getSinapsisSalientes();
            for (int j = 0; j < lista.getTamano(); j++) {
                modelos.Sinapsis s = (modelos.Sinapsis) lista.obtener(j);
                String from = s.getOrigen().getId();
                String to = s.getDestino().getId();
                String eid = from + "_" + to + "_" + j;
                org.graphstream.graph.Edge e = gsGraph.getEdge(eid);
                if (e != null) e.removeAttribute("ui.class");
            }
        }
        // Highlight nodes and path edges
        for (int i = 0; i < ruta.getTamano(); i++) {
            Neurona n = ruta.obtener(i);
            org.graphstream.graph.Node gn = gsGraph.getNode(n.getId());
            if (gn != null) gn.setAttribute("ui.class", "path");
            if (i < ruta.getTamano() - 1) {
                String a = ruta.obtener(i).getId();
                String b = ruta.obtener(i+1).getId();
                // Use model data to find the exact edge id created earlier
                Neurona origen = ruta.obtener(i);
                ListaEnlazada salientes = origen.getSinapsisSalientes();
                for (int k = 0; k < salientes.getTamano(); k++) {
                    modelos.Sinapsis s = (modelos.Sinapsis) salientes.obtener(k);
                    if (s.getDestino().getId().equals(b)) {
                        String eid = a + "_" + b + "_" + k;
                        org.graphstream.graph.Edge e = gsGraph.getEdge(eid);
                        if (e != null) {
                            e.setAttribute("ui.class", "path");
                            break;
                        }
                    }
                }
            }
        }
    }

    private double calcularPesoRuta(ListaEnlazada<Neurona> ruta) {
        double total = 0.0;
        for (int i = 0; i < ruta.getTamano() - 1; i++) {
            Neurona origen = ruta.obtener(i);
            String destinoId = ruta.obtener(i+1).getId();
            ListaEnlazada salientes = origen.getSinapsisSalientes();
            for (int j = 0; j < salientes.getTamano(); j++) {
                modelos.Sinapsis s = (modelos.Sinapsis) salientes.obtener(j);
                if (s.getDestino().getId().equals(destinoId)) {
                    modelos.Neurotransmisor nt = (modelos.Neurotransmisor) miDiccionario.get(s.getIdNeurotransmisor());
                    double velocidad = (nt != null) ? nt.getVelocidad() : 1.0;
                    double w = s.getDistancia() / (velocidad * s.getCoeficienteEficiencia());
                    total += w;
                    break;
                }
            }
        }
        return total;
    }

    private int indexOfNeuron(String id) {
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) {
            if (miGrafo.getNeuronas().obtener(i).getId().equals(id)) return i;
        }
        return -1;
    }

    private void clearAllStyles() {
        for (org.graphstream.graph.Node n : gsGraph) n.removeAttribute("ui.class");
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) {
            Neurona nn = miGrafo.getNeuronas().obtener(i);
            ListaEnlazada lista = nn.getSinapsisSalientes();
            for (int j = 0; j < lista.getTamano(); j++) {
                modelos.Sinapsis s = (modelos.Sinapsis) lista.obtener(j);
                String from = s.getOrigen().getId();
                String to = s.getDestino().getId();
                String eid = from + "_" + to + "_" + j;
                org.graphstream.graph.Edge e = gsGraph.getEdge(eid);
                if (e != null) e.removeAttribute("ui.class");
            }
        }
    }

    private void highlightTraversalDFS(String originId) {
        clearAllStyles();
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) miGrafo.getNeuronas().obtener(i).setVisitada(false);
        int n = miGrafo.getNeuronas().getTamano();
        int start = indexOfNeuron(originId);
        if (start == -1) { statusLabel.setText("Origen no encontrado: " + originId); return; }

        boolean[] visited = new boolean[n];
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) { visited[i] = false; parent[i] = -1; }

        int[] stack = new int[n];
        int top = -1;
        stack[++top] = start;
        while (top >= 0) {
            int u = stack[top--];
            if (!visited[u]) {
                visited[u] = true;
                Neurona nu = miGrafo.getNeuronas().obtener(u);
                ListaEnlazada sal = nu.getSinapsisSalientes();
                for (int j = sal.getTamano() - 1; j >= 0; j--) {
                    modelos.Sinapsis s = (modelos.Sinapsis) sal.obtener(j);
                    int v = indexOfNeuron(s.getDestino().getId());
                    if (v != -1 && !visited[v]) {
                        parent[v] = u;
                        stack[++top] = v;
                    }
                }
            }
        }

        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                String id = miGrafo.getNeuronas().obtener(i).getId();
                org.graphstream.graph.Node gn = gsGraph.getNode(id);
                if (gn != null) gn.setAttribute("ui.class", "dfs");
            }
        }
        for (int i = 0; i < n; i++) {
            if (parent[i] != -1) {
                String from = miGrafo.getNeuronas().obtener(parent[i]).getId();
                String to = miGrafo.getNeuronas().obtener(i).getId();
                Neurona origen = miGrafo.getNeuronas().obtener(parent[i]);
                ListaEnlazada salientes = origen.getSinapsisSalientes();
                for (int k = 0; k < salientes.getTamano(); k++) {
                    modelos.Sinapsis s = (modelos.Sinapsis) salientes.obtener(k);
                    if (s.getDestino().getId().equals(to)) {
                        String eid = from + "_" + to + "_" + k;
                        org.graphstream.graph.Edge e = gsGraph.getEdge(eid);
                        if (e != null) e.setAttribute("ui.class", "dfs");
                        break;
                    }
                }
            }
        }
    }

    private void highlightTraversalBFS(String originId) {
        clearAllStyles();
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) miGrafo.getNeuronas().obtener(i).setVisitada(false);
        int n = miGrafo.getNeuronas().getTamano();
        int start = indexOfNeuron(originId);
        if (start == -1) { statusLabel.setText("Origen no encontrado: " + originId); return; }

        boolean[] visited = new boolean[n];
        int[] parent = new int[n];
        for (int i = 0; i < n; i++) { visited[i] = false; parent[i] = -1; }

        int[] queue = new int[n];
        int head = 0, tail = 0;
        queue[tail++] = start;
        visited[start] = true;
        while (head < tail) {
            int u = queue[head++];
            Neurona nu = miGrafo.getNeuronas().obtener(u);
            ListaEnlazada sal = nu.getSinapsisSalientes();
            for (int j = 0; j < sal.getTamano(); j++) {
                modelos.Sinapsis s = (modelos.Sinapsis) sal.obtener(j);
                int v = indexOfNeuron(s.getDestino().getId());
                if (v != -1 && !visited[v]) {
                    visited[v] = true;
                    parent[v] = u;
                    queue[tail++] = v;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                String id = miGrafo.getNeuronas().obtener(i).getId();
                org.graphstream.graph.Node gn = gsGraph.getNode(id);
                if (gn != null) gn.setAttribute("ui.class", "bfs");
            }
        }
        for (int i = 0; i < n; i++) {
            if (parent[i] != -1) {
                String from = miGrafo.getNeuronas().obtener(parent[i]).getId();
                String to = miGrafo.getNeuronas().obtener(i).getId();
                Neurona origen = miGrafo.getNeuronas().obtener(parent[i]);
                ListaEnlazada salientes = origen.getSinapsisSalientes();
                for (int k = 0; k < salientes.getTamano(); k++) {
                    modelos.Sinapsis s = (modelos.Sinapsis) salientes.obtener(k);
                    if (s.getDestino().getId().equals(to)) {
                        String eid = from + "_" + to + "_" + k;
                        org.graphstream.graph.Edge e = gsGraph.getEdge(eid);
                        if (e != null) e.setAttribute("ui.class", "bfs");
                        break;
                    }
                }
            }
        }
    }

    private void highlightIsolatedNodes(ListaEnlazada<Neurona> aisladas) {
        // Clear existing styles
        for (org.graphstream.graph.Node n : gsGraph) n.removeAttribute("ui.class");
        for (int i = 0; i < miGrafo.getNeuronas().getTamano(); i++) {
            Neurona nn = miGrafo.getNeuronas().obtener(i);
            ListaEnlazada lista = nn.getSinapsisSalientes();
            for (int j = 0; j < lista.getTamano(); j++) {
                modelos.Sinapsis s = (modelos.Sinapsis) lista.obtener(j);
                String from = s.getOrigen().getId();
                String to = s.getDestino().getId();
                String eid = from + "_" + to + "_" + j;
                org.graphstream.graph.Edge e = gsGraph.getEdge(eid);
                if (e != null) e.removeAttribute("ui.class");
            }
        }
        for (int i = 0; i < aisladas.getTamano(); i++) {
            Neurona n = aisladas.obtener(i);
            org.graphstream.graph.Node gn = gsGraph.getNode(n.getId());
            if (gn != null) gn.setAttribute("ui.class", "isolated");
        }
    }

    public void accionAgregarNodo(String id) {
        if (id == null || id.trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese ID válido.");
            return;
        }
        if (miGrafo.buscarNeurona(id) != null) {
            javax.swing.JOptionPane.showMessageDialog(this, "La neurona ya existe.");
            return;
        }
        miGrafo.obtenerOCrearNeurona(id);
        if (gsGraph.getNode(id) == null) {
            org.graphstream.graph.Node gn = gsGraph.addNode(id);
            gn.setAttribute("ui.label", id);
        }
        javax.swing.JOptionPane.showMessageDialog(this, "Neurona agregada: " + id);
    }

    public void accionEliminarNodo(String id) {
        if (id == null || id.trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese ID válido.");
            return;
        }
        boolean removed = miGrafo.eliminarNeurona(id);
        if (!removed) {
            javax.swing.JOptionPane.showMessageDialog(this, "Neurona no encontrada.");
            return;
        }
        if (gsGraph.getNode(id) != null) {
            gsGraph.removeNode(id);
        }
        actualizarGraphStreamDesdeGrafo();
        javax.swing.JOptionPane.showMessageDialog(this, "Neurona eliminada: " + id);
    }

    // Mostrar el diccionario de neurotransmisores en un diálogo
    private void mostrarDiccionario() {
        ListaEnlazada<modelos.Neurotransmisor> list = miDiccionario.getAll();
        if (list.getTamano() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Diccionario vacío.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.getTamano(); i++) {
            modelos.Neurotransmisor nt = list.obtener(i);
            sb.append(String.format("%s - %s - %s - v=%.2f\n", nt.getId(), nt.getNombre(), nt.getEfecto(), nt.getVelocidad()));
            sb.append("  " + nt.getDescripcion() + "\n\n");
        }
        javax.swing.JTextArea area = new javax.swing.JTextArea(sb.toString());
        area.setEditable(false);
        javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(area);
        scroll.setPreferredSize(new java.awt.Dimension(400,300));
        javax.swing.JOptionPane.showMessageDialog(this, scroll, "Diccionario de Neurotransmisores", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }

    // Diálogo para agregar un neurotransmisor manualmente
    private void accionAgregarNeurotransmisorDialog() {
        javax.swing.JTextField fid = new javax.swing.JTextField();
        javax.swing.JTextField fnom = new javax.swing.JTextField();
        javax.swing.JTextField fefect = new javax.swing.JTextField();
        javax.swing.JTextField fvel = new javax.swing.JTextField();
        javax.swing.JTextField fdesc = new javax.swing.JTextField();
        Object[] message = {"ID:", fid, "Nombre:", fnom, "Efecto:", fefect, "Velocidad:", fvel, "Descripción:", fdesc};
        int option = javax.swing.JOptionPane.showConfirmDialog(this, message, "Agregar Neurotransmisor", javax.swing.JOptionPane.OK_CANCEL_OPTION);
        if (option == javax.swing.JOptionPane.OK_OPTION) {
            try {
                String id = fid.getText().trim();
                String nom = fnom.getText().trim();
                String ef = fefect.getText().trim();
                double vel = Double.parseDouble(fvel.getText().trim().replace(",", "."));
                String desc = fdesc.getText().trim();
                modelos.Neurotransmisor nt = new modelos.Neurotransmisor(id, nom, ef, vel, desc);
                miDiccionario.put(id, nt);
                javax.swing.JOptionPane.showMessageDialog(this, "Neurotransmisor agregado: " + id);
            } catch (Exception ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Error en los datos: " + ex.getMessage());
            }
        }
    }

    // Agregar conexión mediante diálogo
    private void accionAgregarConexionDialog() {
        javax.swing.JTextField forigen = new javax.swing.JTextField();
        javax.swing.JTextField fdest = new javax.swing.JTextField();
        javax.swing.JTextField fdist = new javax.swing.JTextField();
        javax.swing.JTextField fneuro = new javax.swing.JTextField();
        javax.swing.JTextField fk = new javax.swing.JTextField();
        Object[] message = {"Origen:", forigen, "Destino:", fdest, "Distancia:", fdist, "ID Neurotransmisor:", fneuro, "k:", fk};
        int option = javax.swing.JOptionPane.showConfirmDialog(this, message, "Agregar Conexión", javax.swing.JOptionPane.OK_CANCEL_OPTION);
        if (option == javax.swing.JOptionPane.OK_OPTION) {
            try {
                String origen = forigen.getText().trim();
                String destino = fdest.getText().trim();
                double distancia = Double.parseDouble(fdist.getText().trim().replace(",", "."));
                String idNeuro = fneuro.getText().trim();
                double k = Double.parseDouble(fk.getText().trim().replace(",", "."));
                miGrafo.conectarNeuronas(origen, destino, distancia, idNeuro, k);
                actualizarGraphStreamDesdeGrafo();
                javax.swing.JOptionPane.showMessageDialog(this, "Conexión agregada: " + origen + " -> " + destino);
            } catch (Exception ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }

    // Eliminar una conexión
    private void accionEliminarConexionDialog() {
        javax.swing.JTextField forigen = new javax.swing.JTextField();
        javax.swing.JTextField fdest = new javax.swing.JTextField();
        Object[] message = {"Origen:", forigen, "Destino:", fdest};
        int option = javax.swing.JOptionPane.showConfirmDialog(this, message, "Eliminar Conexión", javax.swing.JOptionPane.OK_CANCEL_OPTION);
        if (option == javax.swing.JOptionPane.OK_OPTION) {
            String origen = forigen.getText().trim();
            String destino = fdest.getText().trim();
            boolean ok = miGrafo.eliminarSinapsis(origen, destino);
            if (ok) { actualizarGraphStreamDesdeGrafo(); javax.swing.JOptionPane.showMessageDialog(this, "Conexión eliminada."); }
            else { javax.swing.JOptionPane.showMessageDialog(this, "No se encontró la conexión."); }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
