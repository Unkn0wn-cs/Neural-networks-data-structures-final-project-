/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import estructuras.GrafoNeuronal;
import estructuras.ListaEnlazada;
import modelos.Neurona;
import modelos.Sinapsis;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;

/**
 *
 * @author samuel hernandez
 */
/**
 * MonitorVisual
 * Encapsula la representación visual del grafo usando GraphStream y aplica
 * estilos para resaltar rutas, zonas aisladas y otras anotaciones visuales.
 */
public class MonitorVisual {
    private Graph graphStream;

    public MonitorVisual() {
        // Obligatorio para GraphStream 2.0 con interfaces Swing
        System.setProperty("org.graphstream.ui", "swing");
        graphStream = new SingleGraph("Red Sinaptica");
        
        // Estilos CSS para el grafo (opcional pero hace que se vea bien)
        graphStream.setAttribute("ui.stylesheet", 
            "node { fill-color: #A9D0F5; size: 30px; text-size: 16px; text-color: black; } " +
            "edge { fill-color: #5858FA; arrow-size: 15px, 5px; } " +
            "node.aislada { fill-color: #FA5858; }"); // Rojo para zonas aisladas
    }

    /**
     * Requerimiento C: Renderizar el grafo y permitir distribución
     */
    public void renderizarGrafo(GrafoNeuronal miGrafoLogico) {
        graphStream.clear(); // Limpiar visualización anterior

        ListaEnlazada<Neurona> neuronas = miGrafoLogico.getNeuronas();

        // 1. Dibujar todos los Nodos (Neuronas)
        for (int i = 0; i < neuronas.getTamano(); i++) {
            Neurona n = neuronas.obtener(i);
            org.graphstream.graph.Node nodoVisual = graphStream.addNode(n.getId());
            nodoVisual.setAttribute("ui.label", n.getId());
        }

        // 2. Dibujar todas las Aristas (Sinapsis)
        for (int i = 0; i < neuronas.getTamano(); i++) {
            Neurona origen = neuronas.obtener(i);
            ListaEnlazada<Sinapsis> conexiones = origen.getSinapsisSalientes();

            for (int j = 0; j < conexiones.getTamano(); j++) {
                Sinapsis s = conexiones.obtener(j);
                String idArista = origen.getId() + "-" + s.getDestino().getId();
                
                // true al final indica que es un grafo dirigido (con flechas)
                org.graphstream.graph.Edge aristaVisual = graphStream.addEdge(
                    idArista, origen.getId(), s.getDestino().getId(), true
                );
                
                // Mostrar el neurotransmisor en la arista visual
                aristaVisual.setAttribute("ui.label", s.getIdNeurotransmisor());
            }
        }

        // Mostrar la ventana del grafo
        graphStream.display();
    }

    /**
     * Método para pintar de rojo las neuronas inalcanzables (Zonas Aisladas)
     */
    public void resaltarZonasAisladas(ListaEnlazada<Neurona> zonasAisladas) {
        for (int i = 0; i < zonasAisladas.getTamano(); i++) {
            String idAislada = zonasAisladas.obtener(i).getId();
            org.graphstream.graph.Node nodoVisual = graphStream.getNode(idAislada);
            if (nodoVisual != null) {
                nodoVisual.setAttribute("ui.class", "aislada"); // Aplica el CSS rojo
            }
        }
    }
}
