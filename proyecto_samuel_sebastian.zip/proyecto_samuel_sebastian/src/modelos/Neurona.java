package modelos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import estructuras.ListaEnlazada;
/**
 *
 * @author samuel hernandez
 */
/**
 * Neurona
 * Nodo del grafo que contiene un identificador y la lista de sinapsis salientes.
 */
public class Neurona {
  private String id;
    private ListaEnlazada<Sinapsis> sinapsisSalientes; // Lista de adyacencia propia
    private boolean visitada;
    
    public boolean isVisitada() { return visitada; }
    
    public void setVisitada(boolean visitada) { this.visitada = visitada; }
    
    public Neurona(String id) {
        this.id = id;
        this.sinapsisSalientes = new ListaEnlazada<>();
    }

    public String getId() { return id; }
    
    public void agregarSinapsis(Sinapsis sinapsis) {
        this.sinapsisSalientes.agregar(sinapsis);
    }

    public ListaEnlazada<Sinapsis> getSinapsisSalientes() {
        return sinapsisSalientes;
    
    }
}
