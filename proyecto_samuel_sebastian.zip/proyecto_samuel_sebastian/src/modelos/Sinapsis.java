package modelos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author samuel hernandez
 */
/**
 * Sinapsis
 * Representa una arista dirigida entre dos neuronas con distancia,
 * neurotransmisor y coeficiente de eficiencia (k).
 */
public class Sinapsis {
  private Neurona origen;
    private Neurona destino;
    private double distancia;
    private String idNeurotransmisor;
    private double coeficienteEficiencia; // Representa el factor 'k' del enunciado [cite: 41, 75]

    /**
     * Constructor completo para inicializar la sinapsis con los datos del CSV.
     */
    public Sinapsis(Neurona origen, Neurona destino, double distancia, String idNeurotransmisor, double coeficienteEficiencia) {
        this.origen = origen;
        this.destino = destino;
        this.distancia = distancia;
        this.idNeurotransmisor = idNeurotransmisor;
        this.coeficienteEficiencia = coeficienteEficiencia;
    }

    // ==========================================
    // Getters y Setters Estándar
    // ==========================================

    public Neurona getOrigen() { 
        return origen; 
    }

    public Neurona getDestino() { 
        return destino; 
    }

    public double getDistancia() { 
        return distancia; 
    }

    public String getIdNeurotransmisor() { 
        return idNeurotransmisor; 
    }

    public double getCoeficienteEficiencia() { 
        return coeficienteEficiencia; 
    }

    public void setCoeficienteEficiencia(double coeficienteEficiencia) { 
        this.coeficienteEficiencia = coeficienteEficiencia; 
    }

    // ==========================================
    // Métodos Alias (Para compatibilidad con las fórmulas)
    // ==========================================

    /**
     * Alias para obtener el factor de atenuación k usado en la fórmula W = d / (v * k)[cite: 37, 41].
     */
    public double getK() {
        return this.coeficienteEficiencia;
    }

    /**
     * Alias para actualizar el factor k durante la simulación de fatiga cognitiva.
     */
    public void setK(double k) {
        this.coeficienteEficiencia = k;
    }
}
