package modelos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author samuel hernandez
 */
/**
 * Neurotransmisor
 * Representa la ficha química de un neurotransmisor (id, nombre, efecto,
 * velocidad y descripción) usada para calcular pesos en las sinapsis.
 */
public class Neurotransmisor {
private String id;
    private String nombre;
    private String efecto;
    private double velocidad;
    private String descripcion;

    public Neurotransmisor(String id, String nombre, String efecto, double velocidad, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.efecto = efecto;
        this.velocidad = velocidad;
        this.descripcion = descripcion;
    }

    public String getId() { return id; }
    public double getVelocidad() { return velocidad; }
    public String getNombre() { return nombre; }
    public String getEfecto() { return efecto; }
    public String getDescripcion() { return descripcion; }
}

