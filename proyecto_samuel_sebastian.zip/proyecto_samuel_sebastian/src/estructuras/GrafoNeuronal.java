/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructuras;

import modelos.Neurona;
import modelos.Sinapsis;
import modelos.Neurotransmisor; 
import java.io.FileWriter; 
import java.io.PrintWriter;
import java.io.IOException;

/**
 *
 * @author samuel hernandez
 */
/**
 * GrafoNeuronal
 * Representa la red sináptica como un grafo dirigido (lista de adyacencia).
 * Provee operaciones para crear y eliminar neuronas y sinapsis, simular fatiga,
 * calcular la ruta de mayor activación (Dijkstra) y exportar a CSV.
 */
public class GrafoNeuronal {
    private ListaEnlazada<Neurona> neuronas;

    public GrafoNeuronal() {
        this.neuronas = new ListaEnlazada<>();
    }

    // Busca una neurona por ID; si no existe, la crea (Evita duplicados)
    public Neurona obtenerOCrearNeurona(String id) {
        Neurona encontrada = buscarNeurona(id);
        if (encontrada == null) {
            encontrada = new Neurona(id);
            neuronas.agregar(encontrada);
        }
        return encontrada;
    }

    public Neurona buscarNeurona(String id) {
        for (int i = 0; i < neuronas.getTamano(); i++) {
            if (neuronas.obtener(i).getId().equals(id)) {
                return neuronas.obtener(i);
            }
        }
        return null;
    }

    // Conecta dos neuronas de forma unidireccional (Axón a Dendrita)
    public void conectarNeuronas(String idOrigen, String idDestino, double distancia, String idNeuro, double k) {
        Neurona origen = obtenerOCrearNeurona(idOrigen);
        Neurona destino = obtenerOCrearNeurona(idDestino);

        Sinapsis nuevaSinapsis = new Sinapsis(origen, destino, distancia, idNeuro, k);
        origen.agregarSinapsis(nuevaSinapsis);
    }

    public ListaEnlazada<Neurona> getNeuronas() {
        return neuronas;
    }

    /**
     * Requerimiento G: Eliminar una neurona y todas sus conexiones entrantes/salientes.
     */
    public boolean eliminarNeurona(String id) {
        Neurona objetivo = buscarNeurona(id);
        if (objetivo == null) {
            return false; // La neurona no existe
        }

        // 1. Eliminar la neurona de la lista principal de vértices
        for (int i = 0; i < neuronas.getTamano(); i++) {
            if (neuronas.obtener(i).getId().equals(id)) {
                neuronas.eliminar(i);
                break;
            }
        }

        // 2. Limpiar las sinapsis entrantes (recorrer las demás neuronas)
        for (int i = 0; i < neuronas.getTamano(); i++) {
            Neurona actual = neuronas.obtener(i);
            ListaEnlazada<Sinapsis> sinapsis = actual.getSinapsisSalientes();
            
            for (int j = 0; j < sinapsis.getTamano(); j++) {
                if (sinapsis.obtener(j).getDestino().getId().equals(id)) {
                    sinapsis.eliminar(j);
                    j--; // Ajustar el índice porque la lista se redujo
                }
            }
        }
        System.out.println("Neurona " + id + " y sus conexiones han sido eliminadas.");
        return true;
    }

    // =========================================================================
    // MÉTODOS: AVANCE 7 Y 8 (DIJKSTRA, FATIGA COGNITIVA Y PERSISTENCIA)
    // =========================================================================

    /**
     * Requerimiento F: Simular el deterioro cognitivo por fatiga de la red.
     * Incrementa el coeficiente de eficiencia de todas las sinapsis multiplicándolo por 1.2.
     */
    public void simularDeterioroPorFatiga() {
        for (int i = 0; i < neuronas.getTamano(); i++) {
            Neurona actual = neuronas.obtener(i);
            ListaEnlazada<Sinapsis> sinapsis = actual.getSinapsisSalientes();
            
            for (int j = 0; j < sinapsis.getTamano(); j++) {
                Sinapsis s = sinapsis.obtener(j);
                // Multiplicamos el coeficiente actual por 1.2
                double nuevoK = s.getCoeficienteEficiencia() * 1.2;
                s.setCoeficienteEficiencia(nuevoK);
            }
        }
        System.out.println("Simulación de fatiga ejecutada: Coeficientes incrementados en un 20%.");
    }

    /**
     * Requerimiento E: Calcular la Ruta de Mayor Activación (Camino más rápido) mediante Dijkstra.
     * Retorna una ListaEnlazada con las neuronas ordenadas desde el Origen hasta el Destino.
     * @param idOrigen ID de la neurona de salida.
     * @param idDestino ID de la neurona de llegada.
     * @param diccionario Instancia de tu TablaHash para buscar los neurotransmisores O(1).
     */
    public ListaEnlazada<Neurona> calcularRutaMasRapida(String idOrigen, String idDestino, TablaHash diccionario) {
        int n = neuronas.getTamano();
        
        // Estructuras de control indexadas por arreglos nativos (100% legal sin java.util)
        double[] distancias = new double[n];
        boolean[] visitados = new boolean[n];
        int[] predecesores = new int[n];
        
        int idxOrigen = buscarIndiceNeurona(idOrigen);
        int idxDestino = buscarIndiceNeurona(idDestino);
        
        // Validación de existencia de extremos
        if (idxOrigen == -1 || idxDestino == -1) {
            return new ListaEnlazada<>(); // Retorna lista vacía si no existen
        }
        
        // Inicialización de vectores para el algoritmo de Dijkstra
        for (int i = 0; i < n; i++) {
            distancias[i] = Double.MAX_VALUE;
            visitados[i] = false;
            predecesores[i] = -1;
        }
        
        distancias[idxOrigen] = 0.0;
        
        // Bucle iterativo principal de Dijkstra
        for (int cuenta = 0; cuenta < n - 1; cuenta++) {
            // 1. Seleccionar el nodo con la distancia mínima acumulada que no esté visitado
            double min = Double.MAX_VALUE;
            int u = -1;
            
            for (int v = 0; v < n; v++) {
                if (!visitados[v] && distancias[v] <= min) {
                    min = distancias[v];
                    u = v;
                }
            }
            
            // Si ya no hay nodos alcanzables, terminamos
            if (u == -1 || distancias[u] == Double.MAX_VALUE) {
                break;
            }
            
            visitados[u] = true;
            
            // 2. Evaluar las sinapsis salientes de la neurona actual 'u'
            Neurona neuronaActual = neuronas.obtener(u);
            ListaEnlazada<Sinapsis> sinapsisSalientes = neuronaActual.getSinapsisSalientes();
            
            for (int i = 0; i < sinapsisSalientes.getTamano(); i++) {
                Sinapsis s = sinapsisSalientes.obtener(i);
                int vIdx = buscarIndiceNeurona(s.getDestino().getId());
                
                // Si el destino es válido y no ha sido procesado por completo
                if (vIdx != -1 && !visitados[vIdx]) {
                    // Consultar los datos químicos en la Tabla de Dispersión O(1)
                    Neurotransmisor nt = (Neurotransmisor) diccionario.get(s.getIdNeurotransmisor());
                    double velocidad = (nt != null) ? nt.getVelocidad() : 1.0; // Resguardo de seguridad
                    
                    // Aplicación de la fórmula exacta: W = d / (v * k)
                    double pesoArista = s.getDistancia() / (velocidad * s.getCoeficienteEficiencia());
                    
                    // Relajación de la arista dirigida
                    if (distancias[u] + pesoArista < distancias[vIdx]) {
                        distancias[vIdx] = distancias[u] + pesoArista;
                        predecesores[vIdx] = u;
                    }
                }
            }
        }
        
        // 3. Reconstrucción exacta del camino óptimo en orden correcto (Origen -> Destino)
        ListaEnlazada<Neurona> caminoOptimo = new ListaEnlazada<>();
        if (distancias[idxDestino] == Double.MAX_VALUE) {
            return caminoOptimo; // No existe conexión posible entre las neuronas
        }
        
        // Contamos el tamaño del camino para no depender de métodos especiales en tu lista
        int tamCamino = 0;
        int actual = idxDestino;
        while (actual != -1) {
            tamCamino++;
            actual = predecesores[actual];
        }
        
        // Guardamos los nodos en un arreglo temporal de atrás hacia adelante
        Neurona[] temporal = new Neurona[tamCamino];
        actual = idxDestino;
        for (int i = tamCamino - 1; i >= 0; i--) {
            temporal[i] = neuronas.obtener(actual);
            actual = predecesores[actual];
        }
        
        // Insertamos en la ListaEnlazada final en la secuencia correcta
        for (int i = 0; i < tamCamino; i++) {
            caminoOptimo.agregar(temporal[i]);
        }
        
        return caminoOptimo;
    }

    /**
     * Requerimiento F y Criterio 3.2: Guardar el estado actual del grafo en un archivo CSV.
     * Recorre la estructura en memoria y escribe el archivo con el formato exacto requerido.
     * @param rutaArchivo Ruta absoluta o relativa seleccionada por el usuario para guardar.
     * @return true si se guardó con éxito, false en caso de error.
     */
    public boolean guardarGrafoEnCSV(String rutaArchivo) {
        FileWriter fichero = null;
        PrintWriter pw = null;
        try {
            fichero = new FileWriter(rutaArchivo);
            pw = new PrintWriter(fichero);

            // Cabecera exacta del dataset
            pw.println("origen,destino,distancia,ID_Neurotransmisor,coheficiente_eficiencia_sináptica");

            for (int i = 0; i < this.neuronas.getTamano(); i++) {
                Neurona origen = (Neurona) this.neuronas.obtener(i);
                ListaEnlazada<Sinapsis> listaSinapsis = origen.getSinapsisSalientes();

                for (int j = 0; j < listaSinapsis.getTamano(); j++) {
                    Sinapsis s = (Sinapsis) listaSinapsis.obtener(j);
                    
                    // Asegurarse de que el Locale de Java no rompa el CSV con comas decimales
                    String linea = String.format(java.util.Locale.US, "%s,%s,%.2f,%s,%.2f",
                            s.getOrigen().getId(),
                            s.getDestino().getId(),
                            s.getDistancia(),
                            s.getIdNeurotransmisor(),
                            s.getCoeficienteEficiencia()
                    );
                    pw.println(linea); 
                }
            }
            return true;
        } catch (IOException e) {
            System.out.println("Error al exportar: " + e.getMessage());
            return false;
        } finally {
            try {
                if (fichero != null) fichero.close();
            } catch (IOException e2) {
                System.out.println("Error de cierre: " + e2.getMessage());
            }
        }
    }

    /**
     * Método auxiliar interno para mapear el String ID con su índice numérico en la lista global.
     */
    private int buscarIndiceNeurona(String id) {
        for (int i = 0; i < neuronas.getTamano(); i++) {
            if (neuronas.obtener(i).getId().equals(id)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Eliminar una sinapsis dirigida entre dos neuronas (origen -> destino).
     * Retorna true si se eliminó exitosamente.
     */
    public boolean eliminarSinapsis(String idOrigen, String idDestino) {
        Neurona origen = buscarNeurona(idOrigen);
        if (origen == null) return false;
        ListaEnlazada<Sinapsis> sinapsis = origen.getSinapsisSalientes();
        for (int i = 0; i < sinapsis.getTamano(); i++) {
            Sinapsis s = sinapsis.obtener(i);
            if (s.getDestino().getId().equals(idDestino)) {
                sinapsis.eliminar(i);
                return true;
            }
        }
        return false;
    }
}
